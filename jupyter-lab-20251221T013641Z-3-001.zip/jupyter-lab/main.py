def main():
    print("Hello from jupyter-lab!")


if __name__ == "__main__":
    main()
